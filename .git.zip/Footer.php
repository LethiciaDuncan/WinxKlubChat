<?php

?>
 <div class ="footerDiv">
            <footer id="footerText">
                Winx Klub is best Club
            </footer>
     </div>
