<?php

?>
<head>
   

    
    <link rel='stylesheet' type='text/css' href='/Style.css' />
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css2?family=Rowdies:wght@300&display=swap" />
    <style>
            body{
                font-family: 'Rowdies', cursive;
            }
            pre{
                font-family: 'Rowdies', cursive;
            }
    </style>
</head>
<img id="img" src="/Images/logo.png" style="width:50px;height:35px;" />
<div id=" headerDiv"></div>
<br/>
<br />
<ul id="navBar">
    <li>
        <a href="/MessagesPage.php">Messages</a>
    </li>
    <li>
        <a href="/ProfilePage.php">Profile</a>
    </li>
    <li>
        <a href="/Conversations.php">Conversations</a>
    </li>
</ul>

<?php

?>
